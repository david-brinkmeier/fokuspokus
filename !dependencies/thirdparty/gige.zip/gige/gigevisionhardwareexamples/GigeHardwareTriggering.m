%% Hardware-Triggered Acquisition with a GigE Vision Camera
% Copyright 2016 The Mathworks, Inc.

%% Requirements and hardware setup

% MATLAB R2016a or later, Image Acquisition Toolbox, and "GigE Vision Hardware" support package.
% GigE Vision compliant camera with hardware triggering capability; this example uses a Basler acA1300.
% Gigabit Ethernet adapter, which provides a direct camera network connection, configured as described in the "GigE Vision Quick Start Configuration Guide".
% External triggering setup, which can provide a triggering signal to the camera trigger line input. For example, a DAQ device with digital output, an Arduino board, or a function generator instrument can be used to output a custom triggering signal. Refer to the camera user manual for triggering signal voltage level / current requirements and for correct signal connections to the camera input lines.

%% Connect to camera

v = videoinput('gige', 1, 'Mono8');
s = v.Source;

% Determine optimum streaming parameters as described in the
% "GigE Vision Quick Start Configuration Guide"
s.PacketSize = 9000;

%% Immediate acquisition

% Set exposure time and mode
s.ExposureMode = 'Timed';
s.ExposureTimeAbs = 4000;

% The default videoinput trigger type is 'immediate', which is explicitly
% configured here for clarity.
triggerconfig(v, 'immediate');

% Specify number of frames to acquire
v.FramesPerTrigger = 30;
v.TriggerRepeat = 0;

% Start continuous buffered acquisition and wait for acquisition to complete
start(v);
wait(v, 10);

% Transfer acquired frames from acquisition input buffer into workspace.
data = getdata(v, v.FramesAvailable);

figure;
imaqmontage(data)

%% FrameStart Trigger
% Specify total number of frames to be acquired
% One frame is acquired for each external signal pulse.
numFrames = 30;
v.FramesPerTrigger = 1;
v.TriggerRepeat = numFrames - 1;

% Specify 'hardware' videoinput trigger type
triggerconfig(v, 'hardware', 'DeviceSpecific', 'DeviceSpecific');
Configure camera for FrameStart trigger mode and specify external triggering signal input line and desired trigger condition.

% This requires setting the TriggerSelector first; once a TriggerSelector
% value is selected, setting a trigger property (for example,
% TriggerMode to 'on') applies only to the specified trigger mode (FrameStart).
s.TriggerSelector = 'FrameStart';
s.TriggerSource = 'Line1';
s.TriggerActivation = 'RisingEdge';
s.TriggerMode = 'on';

% Specify a constant exposure time for each frame
s.ExposureMode = 'Timed';
s.ExposureTimeAbs = 4000;

% Start hardware-triggered buffered continuous acquisition, and wait for
% acquisition to complete
start(v)
wait(v, 10)

% Transfer acquired frames and timestamps from acquisition input buffer
% into workspace
[data2, ts2] = getdata(v, v.FramesAvailable);

figure;
imaqmontage(data2)

figure;
plot(diff(ts2), '.')
xlabel('Frame index');
ylabel('diff(Timestamp) (s)');

%% Exposure time control

% Specify total number of frames to be acquired
% One frame is acquired for each external signal pulse.
numFrames = 30;
v.FramesPerTrigger = 1;
v.TriggerRepeat = numFrames - 1;

% Specify 'hardware' videoinput trigger type
triggerconfig(v, 'hardware', 'DeviceSpecific', 'DeviceSpecific');
% This requires setting the TriggerSelector first; once a TriggerSelector
% value is selected, setting a trigger property (for example,
% TriggerMode to 'on') applies only to the specified trigger mode (FrameStart).
s.TriggerSelector = 'FrameStart';
s.TriggerSource = 'Line1';
s.TriggerActivation = 'RisingEdge';
s.TriggerMode = 'on';

% For exposure time control, configure a TriggerWidth exposure mode.
s.ExposureMode = 'TriggerWidth';
% Specify camera ExposureOverlapTimeMaxAbs in microseconds
s.ExposureOverlapTimeMaxAbs = 5000;

% Start hardware-triggered buffered continuous acquisition, and wait for
% acquisition to complete
start(v)
wait(v, 10)

% Transfer acquired frames and timestamps from acquisition input buffer
% into workspace
[data3, ts3] = getdata(v, v.FramesAvailable);

figure;
imaqmontage(data3)

figure;
plot(ts3, '.')
xlabel('Frame index');
ylabel('Timestamp (s)');

figure;
plot(diff(ts3), '-x');
xlabel('Frame index');
ylabel('diff(Timestamp) (s)');