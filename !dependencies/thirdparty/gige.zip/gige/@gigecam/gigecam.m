classdef gigecam < imaq.internal.PropertyContainer & matlab.mixin.CustomDisplay
    %GIGECAM Creates gigecam object to acquire frames from a GigE Vision
    %compliant camera.
    %
    %    CAMOBJ = GIGECAM returns a gigecam object, CAMOBJ, that acquires images
    %    from the specified GigE Vision camera. By default, this selects the first
    %    available GigE Vision camera returned by GIGECAMLIST.
    %
    %    CAMOBJ = GIGECAM(CAMINDEX) returns a gigecam object, CAMOBJ, for
    %    the GigE Vision Camera with the specified Camera Index, CAMINDEX. The
    %    Camera Index is the index into the table returned by
    %    GIGECAMLIST.
    %
    %    CAMOBJ = GIGECAM(SERIALNUMBER) returns a gigecam object, CAMOBJ, for
    %    the GigE Vision camera with the specified Serial Number, SERIALNUMBER.
    %    Use GIGECAMLIST to get the serial number of the detected GigE
    %    Vision camera.
    %
    %    CAMOBJ = GIGECAM(IPADDRESS) returns a gigecam object, CAMOBJ, for
    %    the GigE Vision camera with the specified IP Address, IPADDRESS. Use
    %    GIGECAMLIST to get the IP address of the detected GigE Vision
    %    camera.
    %
    %    CAMOBJ = GIGECAM(..., P1, V1, P2, V2,...) constructs the gigecam object,
    %    CAMOBJ, with the specified property values. If an invalid property
    %    name or property value is specified, the gigecam object is not created.
    %
    %    Creating a GIGECAM object obtains exclusive access to the camera.
    %
    %    GIGECAM methods:
    %
    %    snapshot     - Acquire a single frame from the camera.
    %    preview      - Open a live image preview window.
    %    closePreview - Close the live image preview window.
    %    commands     - Get a list of available commands for the camera.
    %    executeCommand - Execute a specified command on the camera.
    %
    %    GIGECAM properties:
    %
    %    DeviceModelName       - The Device Model of the camera.
    %    SerialNumber          - The Serial Number of the camera.
    %    IPAddress             - The IP Address of the camera.
    %    PixelFormat           - The Pixel Format of the image returned by the camera.
    %    AvailablePixelFormats - The Available Pixel Formats for the camera.
    %    Height                - The Height of the image returned by the camera, in pixels.
    %    Width                 - The Width of the image returned by the camera, in pixels.
    %
    %    The GIGECAM interface exposes all the GenICam standard properties
    %    on the GigE Vision camera. Access Beginner, Guru, and Expert
    %    properties by clicking on the hyperlinks in the display.
    %
    %    Example:
    %       % Construct a gigecam object
    %       camObj = gigecam;
    %
    %       % Acquire and display a single image frame.
    %       img = snapshot(camObj);
    %       imshow(img);
    %
    %    See also GIGECAMLIST

    %   Copyright 2014-2019 The MathWorks, Inc.

    properties(GetAccess = public, SetAccess = private)
        %AvailableFormats Specifies the list of available formats of the GigE Vision Camera.
        %   The AvailableFormats property cannot be modified once the
        %   object is created and is read only.
        AvailablePixelFormats

        %SerialNumber Specifies the serial number of the camera.
        SerialNumber

        %IPAddress Specified the IPAddress of the camera.
        IPAddress
    end

    properties(Access = public)
        %Timeout Specifies the time in seconds the snapshot method will wait to get a
        %image data from the camera.
        Timeout
    end

    methods ( Access = public )

        function obj = gigecam(varargin)

            % Call gigecamlist to get a list of all cameras
            warnState = warning('off', 'imaq:gige:gigecamlist:noGigECamsDetected');
            oc = onCleanup(@()warning(warnState));
            cams = gigecamlist();

            numberOfCams = size(cams,1);

            if isempty(numberOfCams) || (numberOfCams == 0)
                error('imaq:gige:gigecamlist:noGigECamsDetected', ...
                    message('imaq:gige:gigecamlist:noGigECamsDetected').getString());
            end

            if(isempty(varargin))% empty arguments - default case of
                % choosing the first available camera
                camIndex = 1;
            else
                inputarg = varargin{1};
                if (isnumeric(inputarg))
                    try
                        validateattributes(inputarg, ...
                            {'numeric'},...
                            {'scalar', '>=', 1, '<=', numberOfCams, ...
                            'nonnan', 'finite'}, 'gigecam', 'CAMINDEX');
                    catch excep
                        throwAsCaller(excep);
                    end
                    camIndex = inputarg;
                    % Accept char or string IP or serial number.
                elseif (imaq.internal.Utils.isCharOrScalarString(inputarg))
                    inputarg = char(inputarg);
                    % Check if it is a valid IP address.
                    [ isIPAddress, camIndex ] = obj.getCamIndexForIPAddress(inputarg, cams);

                    if (~isIPAddress )
                        % Check if it is a valid serial number.
                        [ isSerialNumber, camIndex ] = obj.getCamIndexForSerialNumber(inputarg, cams);
                        if (~isSerialNumber)
                            % The string should be either a valid IPAddress or
                            % a serial number.
                            throwAsCaller(MException('imaq:gige:gigecam:invalidInputArg',...
                                message('imaq:gige:gigecam:invalidInputArg').getString()));
                        end
                    end
                end
            end

            obj.CamIndex = camIndex;
            obj.IPAddress = cams.IPAddress{camIndex};
            obj.SerialNumber = cams.SerialNumber{camIndex};
            obj.Timeout = obj.DefaultTimeout;

            try
                % Create all the controllers with default format.
                obj.createGigeCamControllers('default');
            catch excep
                throwAsCaller(excep);
            end

            % Initialize the maps used for storing information related to property container and easy
            % accessibility of camera properties.
            obj.propertyIndexMap = containers.Map;

            % Add all device specific properties
            obj.addDeviceSpecificProps();

            % Set the Available Formats property
            obj.AvailablePixelFormats = obj.CamController.getAvailableFormats();

            % Get title for the preview window
            previewWindowTitle = obj.getPreviewWindowTitle;

            % Initialize Preview Controller
            obj.CamPreviewController = imaq.supportpackages.gige.internal.PreviewController(previewWindowTitle, obj.CamController);

            % Initialize Categories Controller
            obj.CamCategoryController = imaq.supportpackages.gige.internal.CategoryController( obj, ...
                obj.InternalPropertyContainer);

            % By default only show the beginner properties
            obj.PropertyVisibility = imaq.supportpackages.gige.internal.GigeVisibility.Basic;


            % Set PV pairs if provided.
            if (nargin > 1)

                if ~mod(nargin,2) % If number of arguments is even
                    error('imaq:gige:gigecam:unmatchedPVPairs', message('imaq:gige:gigecam:unmatchedPVPairs').getString);
                end


                for i = 2:2:length(varargin)
                    pName = varargin{i};
                    pValue = varargin{i+1};
                    if imaq.internal.Utils.isScalarString(pName)
                        pName = char(pName);
                    end
                    % Set the value.
                    if imaq.internal.Utils.isScalarString(pValue)
                        pValue = char(pValue);
                    end
                    obj.(pName) = pValue;
                end
            end

            % Set the GevSCPSPacketSize to be equal to the hidden PacketSize
            % property
            try
                obj.GevSCPSPacketSize = obj.PacketSize;
            catch
                % Ignore any error that happen here.
            end

        end

    end

    methods ( Access = private )
        function [ isIPAddress, camIndex ] = getCamIndexForIPAddress(~, ipAddress, availableCams)
            match = cellfun(@(x) strcmp(x, ipAddress), availableCams.IPAddress);
            isIPAddress = any(match);
            camIndex = find(match == 1);
        end

        function [ isSerialNumber, camIndex ] = getCamIndexForSerialNumber(~, serialNumber, availableCams)
            match = cellfun(@(x) strcmp(x, serialNumber), availableCams.SerialNumber);
            isSerialNumber = any(match);
            camIndex = find(match == 1);
        end
    end

    methods ( Access = public )
        function hImage = preview(obj,varargin)
            %PREVIEW Display preview of live video data.
            %
            % PREVIEW(OBJ) creates a Video Preview window that displays
            % live video for gigecam object OBJ. The window also displays
            % the gigecam name, timestamp, resolution and frame rate.
            % The Video Preview window displays the video data at 100%
            % magnification (one screen pixel represents one image pixel).
            %
            % The Video Preview window remains active until it is closed
            % using closePreview. If you clear the GIGECAM object, the Video
            % Preview window stops previewing and closes automatically.
            %
            % HIMAGE = preview(OBJ) returns HIMAGE, a handle to the image
            % object containing the previewed data. To obtain a handle to
            % the figure window containing the image object, use ANCESTOR.
            % For more information about using image objects, see IMAGE.
            %
            % preview(OBJ, HIMAGE) displays live video data for video input
            % object OBJ in the image object specified by the handle
            % HIMAGE. preview scales the image data to fill the entire area
            % of the image object but does not modify the values of any
            % image object properties. Use this syntax to preview video
            % data in a custom GUI of your own design.
            %
            %
            % Custom Update Function
            % ----------------------
            % If you specify the image object where you want preview to
            % display video data, you can also specify a function that
            % preview calls for every update. Preview assigns
            % application-defined data, specified by the name
            % 'UpdatePreviewWindowFcn', to the image object, HIMAGE. Use
            % the SETAPPDATA function, to set the value of
            % 'UpdatePreviewWindowFcn' to a function handle that preview
            % will invoke for each update. You can use this function to
            % perform custom processing of the previewed image data. If
            % 'UpdatePreviewWindowFcn' is configured to [] (the default),
            % preview ignores it. If it is configured to any value other
            % than a function handle or [], preview errors.
            %
            % See also closePreview, snapshot.

            % Invalid number of input arguments.
            narginchk(1, 2);

            % Type checking if image handle was passed in.
            if (nargin==2)
                imHandle = varargin{1};
                validateattributes(imHandle, {'matlab.graphics.primitive.Image'}, {'scalar'}, 'preview', 'Image Handle', 2)
                if ~isvalid(imHandle)
                    imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:invalidImageHandle');
                end
            end

            try
                % Call controller preview.
                imHandle = obj.CamPreviewController.preview(obj.Width,obj.Height,varargin);
            catch excep
                throwAsCaller(excep);
            end
            % Assign output only if requested.
            if(nargout > 0)
                hImage = imHandle;
            end
        end

        function closePreview(obj)
            % CLOSEPREVIEW(OBJ) closes the live preview window for gigecam
            % object, OBJ.
            %
            % See also preview.
            obj.CamPreviewController.closePreview();
        end

        % Execute command on the camera.
        function executeCommand(obj,commandName)
            % EXECUTECOMMAND(OBJ, COMMANDNAME) executes the command on the
            % GigE Vision camera associated with gigecam object, OBJ.
            %
            % See also commands.

            % Call the property containers performCommand method.
            performCommand(obj, commandName);
        end
    end


    methods( Access = public )

        function out = getPreviewWindowTitle(obj)
            % Gets the preview window title.
            % If the camera's GenICam property DeviceModelName is empty,
            % use the IP address instead.
            if ~isempty(obj.DeviceModelName)
                out = obj.DeviceModelName;
            else
                out = obj.IPAddress;
            end
        end

        function [image, timestamp] = snapshot(obj)
            %SNAPSHOT - Acquires a single frame from the gigecam.
            %
            % IMAGE = SNAPSHOT(obj) returns the most recent image from the
            % GIGECAM object, obj.
            %
            % [IMAGE, TIMESTAMP] = SNAPSHOT(obj), returns the timestamp of
            % the acquired image frame. TIMESTAMP is a MATLAB datetime
            % object representing the time the frame was acquired.
            %
            % See also preview.
            try
                [image, timestamp] = obj.CamController.getCurrentFrame(obj.Timeout);
            catch excep
                % rethrow any exceptions caught as caller.
                throwAsCaller(excep)
            end
        end



        function vargout = commands(obj)
            %COMMANDS - Lists the commands available for the gigecam.
            %
            % COMMANDS(obj) returns the list of available commands from the
            % GIGECAM object, obj.
            %
            % COMMANDSLIST = COMMANDS(OBJ) returns the list of avialable
            % commadns in a cell array COMMANDLIST from the GIGECAM object,
            % obj.
            %
            % See also executeCommand.

            pc = obj.InternalPropertyContainer;
            cmds = {};
            for pp=1:length(pc.Properties)
                if strcmp(pc.Properties(pp).Type, 'command')
                    cmds{end+1} = pc.Properties(pp).Name; %#ok<AGROW>
                end
            end

            % If there is a out argument, fill it and do not display
            % commands
            if (nargout == 1)
                vargout = cmds;
                return;
            end

            % Error out if we have no commands available.
            if isempty(cmds)
                fprintf('\n');
                disp(getString(message('imaq:gige:gigecam:noCommands')));
                fprintf('\n');
                return;
            end

            % Display commands like methods.
            fprintf('\n  Available Commands:\n\n')
            for cc=1:length(cmds)
                fprintf('    %s\n', cmds{cc});
            end
            fprintf('\n');

        end

    end
    methods ( Hidden)
        % Implementation of abstract method for internal.PropertyContainer
        function setValueOnProperty(obj, propertyName, value)

            % For pixel format, we need to recreate all the cam controllers
            if strcmp(propertyName, 'PixelFormat')
                obj.setFormat(value);
                return;
            end

            % Check the read-only status before setting a property
            pInfo = propinfo(obj,propertyName);
            switch (pInfo.ReadOnly)
                case 'currently'
                    % If the property is currently readonly. Try to stop
                    % the camera and check if it is still read-only.
                    obj.CamController.stopIfNeeded();
                    % Pause for a moment for the camera to actually stop
                    pause(.1);
                    % get the property to update its propinfo
                    get(obj,propertyName);
                    pInfo = propinfo(obj,propertyName);
                    if strcmp(pInfo.ReadOnly,'currently')
                        obj.CamController.startIfWasStopped();
                        imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:readOnlyProp',propertyName);
                    end
            end

            % Get the internal property container
            pc = obj.InternalPropertyContainer;
            % Get the index for the property to the internal container.
            index = obj.getIndexPropertyContainerIndex(propertyName);
            prop = pc.Properties(index);
            prop.FireListeners = true;

            try
                switch prop.Type
                    case 'integer'

                        % Check for scalar
                        if ~isscalar(value)
                            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:scalarProp',propertyName);
                        end
                        % Check it is numeric
                        if ~isnumeric(value)
                            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:numericProp',propertyName);
                        end

                        % Imaqpropsys expects all ints to be int32
                        value = int32(value);

                        % Check if it is bounds
                        if strcmp(pInfo.Constraint,'bounded')
                            if (value < prop.IntLowerBound)  || (value > prop.IntUpperBound)
                                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:boundedProp',...
                                    propertyName,...
                                    prop.IntLowerBound,...
                                    prop.IntUpperBound);
                            end
                        end

                        % Check if it is being changed according to correct
                        % increments.
                        if ( rem(value,prop.IntIncrement ))
                            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:invalidIncrement',...
                                propertyName,...
                                prop.IntIncrement);
                        end
                        % Set the value
                        prop.IntValue = value;

                    case 'string'
                        if ~imaq.internal.Utils.isCharOrScalarString(value)
                            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:charProp', ...
                                propertyName);
                        end
                        value = char(value);
                        prop.StringValue = value;

                    case 'enum'
                        if ~imaq.internal.Utils.isCharOrScalarString(value)
                            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:charProp', ...
                                propertyName);
                        end
                        value = char(value);
                        % Remove any empty strings
                        validEnumValues = prop.EnumAllowedStrings(~cellfun(@(x) isempty(x),prop.EnumAllowedStrings));
                        if ~ismember(lower(value),lower(validEnumValues))

                            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:invalidEnumString', ...
                                value, ...
                                propertyName,...
                                imaq.supportpackages.gige.internal.Utility.renderCellArrayOfStringsToString(validEnumValues,', '));

                        end
                        for i = 1:numel(prop.EnumAllowedStrings)
                            if strcmpi(value,prop.EnumAllowedStrings{i})
                                value = prop.EnumAllowedStrings{i};
                                break;
                            end
                        end
                        prop.EnumValue = value;

                    case 'double'
                        % Check for scalar
                        if ~isscalar(value)
                            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:scalarProp',propertyName);
                        end
                        % Check for Nan
                        if isnan(value)
                            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:boundedProp',...
                                propertyName,...
                                num2str(prop.DoubleLowerBound),...
                                num2str(prop.DoubleUpperBound));
                        end

                        % Check it is numeric
                        if ~isnumeric(value)
                            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:numericProp',propertyName);
                        end
                        % Check if it is bounds
                        if strcmp(pInfo.Constraint,'bounded')
                            if (value < prop.DoubleLowerBound)  || (value > prop.DoubleUpperBound)
                                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:boundedProp',...
                                    propertyName,...
                                    num2str(prop.DoubleLowerBound),...
                                    num2str(prop.DoubleUpperBound));
                            end
                        end
                        prop.DoubleValue = value;

                    otherwise
                end


                if strcmp(propertyName,'Height')
                    obj.reactToHeightChange(value);
                end

                if strcmp(propertyName,'Width')
                    obj.reactToWidthChange(value);
                end

                if strcmp(propertyName,'GevSCPSPacketSize')
                    obj.reactToPacketSizeChange(value);
                end

                if strcmp(propertyName,'GevSCPD')
                    obj.reactToPacketDelayChange(value);
                end

                obj.CamController.startIfWasStopped();

            catch ME
                obj.CamController.startIfWasStopped();
                throwAsCaller(ME);
            end

        end

        % Implementation of abstract method for internal.PropertyContainer
        function prop = getProperty(obj, propertyName)

            pc = obj.InternalPropertyContainer;

            for pp=1:length(pc.Properties)
                if strcmp(propertyName, pc.Properties(pp).Name) && ~strcmp(pc.Properties(pp).Type, 'Command')
                    % Commands are properties internally, but not to
                    % callers of this method.
                    prop = pc.Properties(pp);
                    return;
                end
            end

            % Error out if property was not found
            error('imaq:videosource:propertyNotFound', 'Invalid property name.');

        end
    end


    methods(Hidden)


        function addDeviceSpecificProps(obj)
            % Adds device specific properties from the internal property
            % container to the gigecam object

            % Get the internal container.The internal property container represents the MCOS C++
            %container imaqpropsys
            internalPropertyContainer = obj.InternalPropertyContainer;

            % Loop through all the properties in the internal container and
            % add them dynamically to the videosource object
            for pp=1:length(internalPropertyContainer.Properties)

                % Set the property name
                property.Name = internalPropertyContainer.Properties(pp).Name;
                
                % Device specific property names matching gigecam interface property names are skipped.
                if ismember(property.Name,["SerialNumber", "IPAddress", "AvailablePixelFormats", "Timeout"])
                    warning(message('imaq:gige:gigecam:gigecamDefinedProperties', property.Name));
                    continue;
                end
                
                % Set the read only property
                property.ReadOnly = false;

                % Set the visibility of the property
                property.Visibility = internalPropertyContainer.Properties(pp).Visibility;

                % Add the property dynamically
                prop = obj.addDynamicProp(property);

                % Make the 'command' property hidden
                if strcmp(internalPropertyContainer.Properties(pp).Type, 'command')
                    prop.Hidden = true;
                end

                % Store the index relative to the name of the property.
                obj.propertyIndexMap(property.Name) = pp;

            end
        end

        function h = createDynamicPropertyGetter(obj,propertyName)
            h = @updatePropertyValue;

            function value = updatePropertyValue(src,evt) %#ok<INUSD>
                pc = obj.InternalPropertyContainer;

                index = obj.getIndexPropertyContainerIndex(propertyName);
                prop = pc.Properties(index);
                prop.FireListeners = true;
                obj.PerformingGet = true;
                try
                    switch prop.Type
                        case 'integer'
                            if prop.StorageType == 4
                                value = prop.IntValue;
                            else
                                value = prop.IntArrayValue;
                            end
                        case 'string'
                            value = prop.StringValue;
                        case 'enum'
                            value = prop.EnumValue;
                        case 'double'
                            if prop.StorageType == 2
                                value = prop.DoubleValue;
                            else
                                value = prop.DoubleArrayValue;
                            end
                        otherwise
                            value = [];
                    end
                catch excep
                    throwAsCaller(excep)
                end
                obj.PerformingGet = false;

            end
        end

        function dispPropertyGroup(obj, properties, ident)

            ident = repmat(' ',1,ident);
            cr = newline;
            propertiesDispStr = '';

            % Loop through all the properties
            for i=1:length(properties)

                try
                    propertyToDisplay = obj.([properties{i}]);
                catch excep
                    if strcmp(excep.identifier,'imaq:gige:gigecam:genicamPropUnavailable')
                        propertyToDisplay = obj.InaccessibleProprtyValueDisplay;
                    else
                        rethrow(excep);
                    end
                end

                % Construct the display string based on the data type
                if isnumeric(propertyToDisplay) && ~isscalar(propertyToDisplay)
                    % Display for Arrays Case
                    arrayStr = sprintf('%.5g ',propertyToDisplay);
                    strToDisp = sprintf('%s%s = [%s', ident,properties{i}, arrayStr);
                    strToDisp(end) =  ']';
                    strToDisp(end+1) = cr; %#ok<AGROW>
                elseif isempty(propertyToDisplay)
                    % Empty Property Case
                    pInfo = propinfo(obj,properties{i});
                    strToDisp = [sprintf('%s%s = [%dx%d %s]', ident,properties{i}, size(propertyToDisplay),pInfo.Type), cr];
                elseif iscell(propertyToDisplay)
                    % Cell Array Case
                    numOfElementsOfCell = size(propertyToDisplay,2);
                    formatStr = '%s';
                    for j = 1:numOfElementsOfCell-1
                        formatStr = [ formatStr, ',%s']; %#ok<AGROW>
                    end
                    strToDisp = [sprintf(['%s%s = ' formatStr], ident, properties{i}, propertyToDisplay{:}), cr];
                else
                    % All other numeric properties
                    strToDisp = [sprintf('%s%s = %s',ident, properties{i}, num2str(propertyToDisplay)), cr];
                end

                propertiesDispStr = [ propertiesDispStr strToDisp]; %#ok<AGROW>

            end

            % Print it to command prompt
            if ~isempty(propertiesDispStr)
                fprintf('%s', propertiesDispStr);
            end

        end

        % Filter properties to display based on the property visibility
        function result = filterProperties(obj,propertiesList)

            % Initialize to cell array
            result = {};


            switch obj.PropertyVisibility
                case imaq.supportpackages.gige.internal.GigeVisibility.Basic
                    % Loop through the properties to check GenICam visibility
                    % setting
                    for iProp = 1:numel(propertiesList)
                        propertyName = propertiesList{iProp};
                        index = getIndexPropertyContainerIndex(obj,propertyName);
                        % Add to the list only if the property is 'basic'
                        if (strcmp(obj.InternalPropertyContainer.Properties(index).Visibility, ...
                                'basic'))
                            result = [ result propertyName]; %#ok<AGROW>
                        end
                    end
                case imaq.supportpackages.gige.internal.GigeVisibility.Medium
                    % Loop through the properties to check GenICam visibility
                    % setting
                    for iProp = 1:numel(propertiesList)
                        propertyName = propertiesList{iProp};
                        index = getIndexPropertyContainerIndex(obj,propertyName);
                        % Add to the list only if the property is 'basic'
                        % or 'medium'
                        if (strcmp(obj.InternalPropertyContainer.Properties(index).Visibility, ...
                                'basic') || strcmp(obj.InternalPropertyContainer.Properties(index).Visibility, ...
                                'medium') )
                            result = [ result propertyName]; %#ok<AGROW>
                        end
                    end
                case imaq.supportpackages.gige.internal.GigeVisibility.Full
                    result = propertiesList;
                    return;
            end
        end
    end

    methods(Access = private)

        % React to the Height property being changed.
        function reactToHeightChange(obj,newValue)
            obj.CamController.stopIfNeeded();
            if  (isPreviewing(obj))
                obj.CamPreviewController.replaceImage(obj.Width,newValue,obj.getNumBands());
            end
            obj.CamController.startIfWasStopped()
        end

        % React to the Width property being changed.
        function reactToWidthChange(obj,newValue)
            obj.CamController.stopIfNeeded();
            if(isPreviewing(obj))
                obj.CamPreviewController.replaceImage(newValue,obj.Height,obj.getNumBands());
            end
            obj.CamController.startIfWasStopped()
        end

        function reactToPacketSizeChange(obj,newValue)
            obj.PacketSize = newValue;
        end

        function reactToPacketDelayChange(obj,newValue)
            obj.PacketDelay = newValue;
        end

        function createGigeCamControllers(obj,format)

            try
                % Create the controller object
                obj.CamController = ...
                    imaq.supportpackages.gige.internal.GigeCamController(obj.SerialNumber,obj.IPAddress, format);
            catch excep
                throwAsCaller(excep)
            end
            % Get the internal imaqpropsys container which is stored as a
            % device specific property on the AsyncIO channel
            internalPropertyContainer = obj.CamController.getPropertyContainer();


            % The internal property container is a device specific property
            % on the AsyncIO channel.
            obj.InternalPropertyContainer = internalPropertyContainer;

        end

        function index = getIndexPropertyContainerIndex(obj,propertyName)
            % A helper function to get the index of a property in the
            % internal property container. Return empty if the property is
            % not found.
            if isKey(obj.propertyIndexMap,propertyName)
                index = obj.propertyIndexMap(propertyName);
            else
                index = [];
            end

        end

        % Sort based on the lower case, however return the correct case.
        function result = sortAlphabetically(obj,propertyNames) %#ok<INUSL>
            [ ~, iS]  = sort(lower(propertyNames));
            result = propertyNames(iS);
        end

        function result =  getAlphabeticallySortedPropertyNames(obj)
            result = obj.sortAlphabetically(properties(obj));
        end

        function result = getDisplayTextForEnumProperty(obj,propName)
            pInfo = propinfo(obj,propName);
            result = '[';
            for indexConstraintValue = 1:length(pInfo.ConstraintValue)
                if strcmp(pInfo.ConstraintValue{indexConstraintValue},pInfo.DefaultValue)
                    result = [ result sprintf(' {%s} ',pInfo.ConstraintValue{indexConstraintValue})]; %#ok<AGROW>
                else
                    result = [ result sprintf(' %s ',pInfo.ConstraintValue{indexConstraintValue})]; %#ok<AGROW>
                end
                if indexConstraintValue ~= length(pInfo.ConstraintValue)
                    result = [ result '|']; %#ok<AGROW>
                end
            end
            result(end+1) = ']';
        end

        function tf = isPreviewing(obj)
            tf = false;
            if ( ~isempty(obj.CamPreviewController) && obj.CamPreviewController.isPreviewing() )
                tf = true;
            end
        end

    end

    methods (Access = private)
        function result = getDeviceSpecificPropertyNames(obj)
            propertyNames = sortAlphabetically(obj,properties(obj));
            result = propertyNames(cellfun(@(x) ~isempty(obj.getIndexPropertyContainerIndex(x)), ...
                propertyNames));

        end

        function result = isReadOnly(obj,propName)

            % Only Timeout is a writable non-device specific property.
            if strcmp(propName, 'Timeout')
                result = false;
                return;
            end

            % For all other non-device specific properties, return true.
            index = obj.getIndexPropertyContainerIndex(propName);
            if isempty(index)
                result = true;
                return;
            end

            result = strcmp(obj.InternalPropertyContainer.Properties(index).ReadOnly,'currently') || ...
                     strcmp(obj.InternalPropertyContainer.Properties(index).ReadOnly,'whileRunning') || ...
                     strcmp(obj.InternalPropertyContainer.Properties(index).ReadOnly,'always');
        end

        function result = isEnum(obj,propName)
            index = obj.getIndexPropertyContainerIndex(propName);
            if isempty(index)
                result = false;
                return;
            end
            result = strcmp(obj.InternalPropertyContainer.Properties(index).Type,'enum');
        end

        function setFormat(obj,newFormat)
            if ~imaq.internal.Utils.isCharOrScalarString(newFormat)
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:charProp', ...
                    'PixelFormat');
            end
            newFormat = char(newFormat);

            if ~ismember(lower(newFormat),lower(obj.AvailablePixelFormats))
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:invalidEnumString', ...
                    newFormat, ...
                    'PixelFormat',...
                    imaq.supportpackages.gige.internal.Utility.renderCellArrayOfStringsToString(obj.AvailablePixelFormats,', '));

            end
            for i = 1:numel(obj.AvailablePixelFormats)
                if strcmpi(newFormat,obj.AvailablePixelFormats{i})
                    newFormat = obj.AvailablePixelFormats{i};
                    break;
                end
            end

            % Check if we were previewing before we delete the controllers
            isPreviewing = obj.isPreviewing();

            % Cache the height and width
            width = obj.Width;
            height = obj.Height;

            % Get this device specific property from the controller
            delete(obj.CamController);

            obj.createGigeCamControllers(newFormat);

            % Re Initialize Preview Controller
            obj.CamPreviewController.setCamController(obj.CamController);

            % Set the height and width to last known value
            obj.Width = width;
            obj.Height = height;

            % Set the GevSCPSPacketSize to be equal to the hidden PacketSize
            % property
            try
                obj.GevSCPSPacketSize = obj.PacketSize;
            catch
                % Ignore any error that happen here.
            end

            % If we were previewing, restart preview
            if (isPreviewing)
                obj.preview();
            end
        end
    end


    methods ( Hidden )
        function showBeginnerCameraProperties(obj,gigecamObjectVariableName)
            obj.PropertyVisibility = 'beginner';
            obj.showCameraProperties(gigecamObjectVariableName);
        end

        function showExpertCameraProperties(obj,gigecamObjectVariableName)
            obj.PropertyVisibility = 'expert';
            obj.showCameraProperties(gigecamObjectVariableName);
        end

        function showGuruCameraProperties(obj,gigecamObjectVariableName)
            obj.PropertyVisibility = 'guru';
            obj.showCameraProperties(gigecamObjectVariableName);
        end

        function showCameraProperties(obj,objName)
            indent = blanks(obj.BasicIndentationLength);

            %Delegate the display to the category handler.
            obj.CamCategoryController.disp();

            % Now show the all properties hyperlink.
            if matlab.internal.display.isHot
                fprintf('\n');
                % Message catalog does not support resuing holes.
                link1 = [ indent getString(message('imaq:gige:gigecam:showCameraProperties',objName,objName,objName, objName, ...
                    objName,objName,objName, objName, ...
                    objName,objName,objName, objName))];
                disp(link1);
                disp([ indent getString(message('imaq:gige:gigecam:showCameraCommands',objName,objName,objName,objName))]);
            end
        end

        function showAllCameraProperties(obj)
            % Temporarily change the Property Visibility to all.
            obj.PropertyVisibility = imaq.supportpackages.gige.internal.GigeVisibility.Full;
            obj.CamCategoryController.disp();
            obj.PropertyVisibility = imaq.supportpackages.gige.internal.GigeVisibility.Basic;
        end

        function delete(obj)
            try
                if (~isempty(obj.CamController)&& isvalid(obj.CamController))
                    obj.CamController.delete();
                    obj.CamController = [];
                end
                if (~isempty(obj.CamPreviewController)&& isvalid(obj.CamPreviewController))
                    obj.CamPreviewController.delete();
                    obj.CamPreviewController = [];
                end
            catch excep
                throwAsCaller(excep);
            end

        end
    end
    properties ( Access = private, Hidden )
        % A map between property name and its index in the internal
        % property container
        propertyIndexMap;

        % Index for the gigecam object
        CamIndex

        % Handles all operations with the AsyncIO channel
        CamController

        % Handles all the preview operations
        CamPreviewController

        % Handles all the category related operation for the camera.
        CamCategoryController
    end

    properties (Constant, Hidden)
        % The indentation used in all displays
        BasicIndentationLength = 3;

        % Next level indentation
        Level1IndentationLength = 5;

        % Imaqpropsys visibility name for basic
        BasicPropertyContainerVisibility = 'basic';

        % Not accessible property value
        InaccessibleProprtyValueDisplay = '(Currently not accessible)';

        % Default timeout at gigecam creation
        DefaultTimeout = 10;
    end

    properties ( Hidden )
        % Hidden property that controls if only the basic or all properties
        % are shown.
        PropertyVisibility = imaq.supportpackages.gige.internal.GigeVisibility.Basic;
    end

    methods
        function set.PropertyVisibility(obj,newPropertyVisibility)
            switch newPropertyVisibility
                case {'basic','beginner'}
                    obj.PropertyVisibility = imaq.supportpackages.gige.internal.GigeVisibility.Basic;
                case {'medium','expert'}
                    obj.PropertyVisibility = imaq.supportpackages.gige.internal.GigeVisibility.Medium;
                case {'full','guru'}
                    obj.PropertyVisibility = imaq.supportpackages.gige.internal.GigeVisibility.Full;
            end
        end

        function set.Timeout(obj,newTimeout)

            % Check it is numeric
            if ~isnumeric(newTimeout)
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:numericProp','Timeout');
            end

            % Check for scalar if not inf.
            if ~isscalar(newTimeout) && ~isInf(newTimeout)
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:scalarProp','Timeout');
            end

            % Check for Nan
            if isnan(newTimeout)
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:nanProp','Timeout');
            end

            % Check for negative
            if newTimeout < 0
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:boundedProp',...
                    'Timeout',...
                    0,...
                    'Inf');
            end

            obj.Timeout = newTimeout;

        end
    end

    methods (Access = protected)
        function header = getHeader(obj)

            indent = blanks(obj.BasicIndentationLength);

            % Display the summary line
            name = matlab.mixin.CustomDisplay.getClassNameForHeader(obj);
            childHeading = [indent 'Display Summary for ' name];
            header = sprintf('%s:\n', childHeading);
        end

        function group = getPropertyGroups(obj) %#ok<MANU>
            group = matlab.mixin.util.PropertyGroup( {'DeviceModelName','SerialNumber','IPAddress','PixelFormat','AvailablePixelFormats','Height','Width','Timeout'},'');

        end

        function footer = getFooter(obj)
            footer = '';
            indent = blanks(obj.BasicIndentationLength);

            if matlab.internal.display.isHot
                % Message catalog does not support resuing holes.
                link1 = [ indent getString(message('imaq:gige:gigecam:showCameraProperties',inputname(1),inputname(1),inputname(1), inputname(1), ...
                    inputname(1),inputname(1),inputname(1), inputname(1), ...
                    inputname(1),inputname(1),inputname(1), inputname(1)))];
                % Get a list of available commands.
                if( ~isempty(obj.commands()) )
                    link2 = [ indent getString(message('imaq:gige:gigecam:showCameraCommands',inputname(1),inputname(1),inputname(1),inputname(1)))];
                    footer = sprintf('%s\n%s',link1,link2');
                    return
                end
                footer = sprintf('%s',link1);
            end

        end
    end

    methods ( Hidden )

        % Hide methods from the differnet superclass that gigecam should
        % not expose

        function res = addprop(obj, varargin)
            res = addprop@dynamicprops(obj, varargin{:});
        end

        function varargout = setdisp(obj,varargin)
            if nargout > 0
                varargout = setdisp@hgsetget(obj, varargin{:});
            else
                setdisp@hgsetget(obj, varargin{:});
            end
        end

        function  varargout = getdisp(obj,varargin)
            if nargout > 0
                varargout = getdisp@hgsetget(obj, varargin{:});
            else
                getdisp@hgsetget(obj, varargin{:});
            end
        end

        function pInfo = propinfo(obj, propertyName)
            pInfo = propinfo@imaq.internal.PropertyContainer(obj,propertyName);
            pInfo.Accessible = true;
            try
                obj.(propertyName);
            catch excep
                if strcmp(excep.identifier,'imaq:gige:gigecam:genicamPropUnavailable')
                    pInfo.Accessible = false;
                end
            end

        end

        function closepreview(~)
            imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:invalidClosePreview');
        end

        function c = horzcat(varargin)
            %HORZCAT Horizontal concatenation of gigecam objects.
            if (nargin == 1)
                c = varargin{1};
            else
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:noconcatenation');
            end
        end

        function c = vertcat(varargin)
            %VERTCAT Vertical concatenation of gigecam objects.

            if (nargin == 1)
                c = varargin{1};
            else
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:noconcatenation');
            end
        end

        function c = cat(varargin)
            %CAT Concatenation of giegcam objects.
            if (nargin > 2)
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:noconcatenation');
            else
                c = varargin{2};
            end
        end
    end

    methods
        function varargout = set(obj, varargin)
            % Perform a get to get all updated prop info.
            out = get(obj);
            sortedPropertyNames = obj.getAlphabeticallySortedPropertyNames();

            try
                %% set(obj)
                if nargin == 1  && nargout == 0

                    % Show device properties if they exists.
                    for propIndex = 1:numel(sortedPropertyNames)
                        if obj.isReadOnly(sortedPropertyNames{propIndex})
                            continue;
                        end
                        if obj.isEnum(sortedPropertyNames{propIndex})
                            fprintf('%4s%s:%s\n','',sortedPropertyNames{propIndex},...
                                obj.getDisplayTextForEnumProperty(sortedPropertyNames{propIndex}))
                        else
                            fprintf('%4s%s\n','', sortedPropertyNames{propIndex})
                        end
                    end
                    fprintf('\n');
                    return;
                end


                %% out = set(obj)
                if nargin == 1 && nargout == 1
                    a = struct;
                    sortedPropertyNames = obj.getAlphabeticallySortedPropertyNames();

                    for i=1:length(sortedPropertyNames)
                        try
                            p = propinfo(obj,sortedPropertyNames{i});
                            if obj.isReadOnly(sortedPropertyNames{i})
                                continue;
                            end
                            if obj.isEnum(sortedPropertyNames{i})
                                a.(sortedPropertyNames{i}) = p.ConstraintValue';
                            else
                                a.(sortedPropertyNames{i}) = {};
                            end
                        catch
                            % For non device specific properties, propinfo will throw an error. Ignore it.
                            a.(sortedPropertyNames{i}) = {};
                        end
                    end
                    varargout = {a};
                    return;
                end

                %% set(obj,'PropName')
                if nargin == 2
                    % If the input is a string, convert it to char. Example: set(g,"PixelFormat")
                    if imaq.internal.Utils.isScalarString(varargin{1})
                        varargin{1} = char(varargin{1});
                    end
                    propName = varargin{1};
                    if ~isstruct(propName)
                        pInfo = propinfo(obj,propName);
                        if obj.isReadOnly(propName)
                            strToDisp = sprintf('The ''%s'' property is currently readonly.\n', propName);
                        elseif obj.isEnum(propName)
                            strToDisp = sprintf('%s\n',obj.getDisplayTextForEnumProperty(propName));
                            out = pInfo.ConstraintValue';
                        else
                            strToDisp = sprintf('The ''%s'' property does not have a fixed set of property values.\n', propName);
                            out = {};
                        end
                        if nargout ~= 0
                            varargout = {out};
                        else
                            fprintf(strToDisp);
                        end
                        return;
                    end
                end

                %% set(obj,'PropName','PropValue')
                %% out = set(obj,'PropName','PropValue')
                % If there are string inputs, convert them to char.
				% Example: set(g,"Height",100,"Width",100);
                for i = 1:nargin-1
                    if imaq.internal.Utils.isScalarString(varargin{i})
                        varargin{i} = char(varargin{i});
                    end
                end

                out = {set@hgsetget(obj,varargin{:})};
                if nargout ~= 0
                    varargout = out;
                end


            catch ME
                ME.throwAsCaller;
            end

        end

        function varargout = get(obj, varargin)
            sortedPropertyNames = obj.getAlphabeticallySortedPropertyNames();

            if nargin == 1 && nargout == 0 % user called get(obj)
                dispPropertyGroup(obj, sortedPropertyNames, obj.Level1IndentationLength);
            end

            for i = 1:nargin-1
                % Case 1: get(g,"PixelFormat")
                if imaq.internal.Utils.isScalarString(varargin{i})
                    varargin{i} = char(varargin{i});
                else
                    % Case 2:  get(g,{"PixelFormat","Height"})
                    if iscell(varargin{i})
                        for j = 1:numel(varargin{i})
                            if imaq.internal.Utils.isScalarString(varargin{i}{j})
                                varargin{i}{j} = char(varargin{i}{j});
                            end
                        end
                    end
                end
            end

            % user called out = get(obj,propertyName)
            if nargin > 1
                try
                    varargout = {get@hgsetget(obj,varargin{:})};
                catch excep
                    throwAsCaller(excep)
                end
            end

            if nargout > 0 && nargin == 1 % user calls out = get(obj)
                sortedGet  = struct([]);
                for index = 1:length(obj)
                    f = sortedPropertyNames;
                    % Loop through each property. If the property is innaccessible, the display the
                    % inacccessible string.
                    for i = 1:length(f)
                        try
                            sortedGet(index,1).(f{i}) = obj.(f{i});
                        catch
                            sortedGet(index,1).(f{i}) = obj.InaccessibleProprtyValueDisplay;
                        end
                    end
                end
                varargout = {sortedGet};
            end
        end
    end
    methods ( Hidden )
        function numBands = getNumBands(obj)
            if strfind(obj.PixelFormat,'Mono')
                numBands = 1;
            else
                numBands = 3;
            end
        end
    end

    methods (Sealed, Hidden)
        function obj = saveobj(obj)
            % saveobj Saves the gigecam information to file.
            %
            %   OBJ = saveobj(OBJ) saves the gigecam for future loading.

            % Set object properties into a structure for saving. Turn the
            % warning off to so that it does not show to the user.
            warnState = warning('OFF', 'MATLAB:structOnObject');
            saveInfo = struct(obj);
            warning(warnState);

            % Remove fields that should not be saved.
            saveInfo = rmfield(saveInfo, 'CamController');
            saveInfo = rmfield(saveInfo, 'CamPreviewController');

            % Set the output to save.
            obj = saveInfo;
        end
    end

    methods( Static, Hidden)
        function obj = loadobj(inStruct)
            % LOADOBJ Load gigecam object from memory.

            try
                % Try creating the object.
                obj = gigecam(inStruct.SerialNumber);
            catch
                imaq.supportpackages.gige.internal.Utility.localizedError('imaq:gige:gigecam:cannotCreateObject',inStruct.SerialNumber)
            end

            % Remove all the internal fields
            inStruct = rmfield(inStruct, 'AvailablePixelFormats');
            inStruct = rmfield(inStruct, 'SerialNumber');
            inStruct = rmfield(inStruct, 'IPAddress');
            inStruct = rmfield(inStruct, 'propertyIndexMap');
            inStruct = rmfield(inStruct, 'CamIndex');
            inStruct = rmfield(inStruct, 'CamCategoryController');
            inStruct = rmfield(inStruct, 'BasicIndentationLength');
            inStruct = rmfield(inStruct, 'Level1IndentationLength');
            inStruct = rmfield(inStruct, 'BasicPropertyContainerVisibility');
            inStruct = rmfield(inStruct, 'InaccessibleProprtyValueDisplay');
            inStruct = rmfield(inStruct, 'DefaultTimeout');
            inStruct = rmfield(inStruct, 'PropertyVisibility');
            inStruct = rmfield(inStruct, 'PerformingGet');
            inStruct = rmfield(inStruct, 'PreGetListeners');
            inStruct = rmfield(inStruct, 'PreSetListeners');
            inStruct = rmfield(inStruct, 'InternalPropertyContainer');

            % Restore properties.
            cameraPropertyNames = fieldnames(inStruct);
            couldNotRestoreAtleastOneProperty = false;

            for iProps = 1: numel(cameraPropertyNames)
                try
                    % Set the property values.
                    set(obj, cameraPropertyNames{iProps},inStruct.(cameraPropertyNames{iProps}));
                catch e
                    % If it is a read only property, ignore the error
                    if strcmp(e.identifier,'imaq:gige:gigecam:readOnlyProp')
                        continue;
                    end
                    couldNotRestoreAtleastOneProperty = true;
                end
            end

            if (couldNotRestoreAtleastOneProperty)
                imaq.supportpackages.gige.internal.Utility.localizedWarning('imaq:gige:gigecam:cannotRestoreProperties');
            end
        end

    end
end
