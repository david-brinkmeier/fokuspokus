function mwgigeimaq
% MWGIGEIMAQ Stub placeholder for finding adaptor  location.

% Copyright 2014 The MathWorks, Inc.